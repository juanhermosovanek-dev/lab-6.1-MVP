export type Student = {
  id: string;
  user_id: string;
  name: string;
  year: string;
  subject: string;
  attendance: number;
  grade_t1: number;
  grade_t2: number;
  status: 'good' | 'warn' | 'danger';
  created_at: string;
};

export type Observation = {
  id: string;
  student_id: string;
  teacher_name: string;
  content: string;
  created_at: string;
};

export type DatabaseError = {
  message: string;
  details?: string;
};
