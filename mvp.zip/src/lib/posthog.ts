import posthog from 'posthog-js';

const posthogKey = import.meta.env.VITE_POSTHOG_KEY;
const posthogHost = import.meta.env.VITE_POSTHOG_HOST || 'https://us.i.posthog.com';

export const initPostHog = () => {
    if (typeof window !== 'undefined' && posthogKey) {
        posthog.init(posthogKey, {
            api_host: posthogHost,
            loaded: (ph) => {
                if (import.meta.env.DEV) ph.opt_out_capturing();
            },
        });
    }
};

export const trackEvent = (eventName: string, properties?: Record<string, any>) => {
    if (posthogKey) {
        posthog.capture(eventName, properties);
    }
};
