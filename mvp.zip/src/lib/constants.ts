export const MOCK_TEACHERS = [
  'Sra. Marta Rodriguez (History)',
  'Prof. Carlos Alvarez (Mathematics)',
  'Sra. Ana Gomez (Language & Literature)',
  'Prof. Luis Pereyra (Biology)',
  'Prof. Diego Santos (Physical Education)'
];

export const calculateStatus = (grade_t2: number): 'good' | 'warn' | 'danger' => {
  if (grade_t2 >= 7) return 'good';
  if (grade_t2 >= 6) return 'warn';
  return 'danger';
};
