import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { trackEvent } from '../lib/posthog';
import { useAuth } from '../context/AuthContext';
import { Student } from '../types';
import Sidebar from '../components/Sidebar';
import StudentDetail from '../components/StudentDetail';
import AddStudentModal from '../components/AddStudentModal';
import { LogOut } from 'lucide-react';

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const schoolName = user?.user_metadata?.school_name || 'Mi Colegio';

  useEffect(() => {
    fetchStudents();
  }, [user]);

  const fetchStudents = async () => {
    try {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setStudents(data || []);
    } catch (error) {
      console.error('Error fetching students:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    trackEvent('user_logged_out');
    navigate('/login');
  };

  const selectedStudent = students.find(s => s.id === selectedStudentId);

  return (
    <div className="flex h-screen bg-root text-text-primary overflow-hidden">
      {/* Sidebar - 220px width */}
      <div className="w-[220px] shrink-0 border-r border-border-card bg-panel flex flex-col h-full">
        <div className="h-14 flex items-center justify-between px-4 border-b border-border-card shrink-0">
          <span className="font-semibold text-sm truncate pr-2">{schoolName}</span>
          <button onClick={handleLogout} className="text-text-secondary hover:text-white transition-colors">
            <LogOut className="w-4 h-4" />
          </button>
        </div>
        
        <Sidebar 
          students={students} 
          selectedId={selectedStudentId} 
          onSelect={(id) => {
            setSelectedStudentId(id);
            trackEvent('student_selected', { student_id: id });
          }}
          onAddClick={() => setIsAddModalOpen(true)}
          loading={loading}
        />
      </div>

      {/* Main Area */}
      <div className="flex-1 overflow-hidden h-full">
        <div className="h-14 border-b border-border-card flex items-center px-8 shrink-0 bg-root">
          <h1 className="text-lg font-semibold">
            {selectedStudent ? selectedStudent.name : 'Panel Central'}
          </h1>
        </div>

        <div className="h-[calc(100vh-56px)] overflow-y-auto p-8 relative">
          {selectedStudent ? (
            <StudentDetail 
              student={selectedStudent} 
              onUpdate={fetchStudents} 
              onDelete={() => {
                setSelectedStudentId(null);
                fetchStudents();
              }}
            />
          ) : (
            <div className="h-full flex items-center justify-center text-text-secondary flex-col">
              <svg className="w-16 h-16 mb-4 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
              <p>Seleccioná un alumno para ver su progreso</p>
            </div>
          )}
        </div>
      </div>

      {isAddModalOpen && (
        <AddStudentModal 
          onClose={() => setIsAddModalOpen(false)} 
          onSuccess={(newStudent) => {
            fetchStudents();
            setIsAddModalOpen(false);
            setSelectedStudentId(newStudent.id);
          }}
        />
      )}
    </div>
  );
}
