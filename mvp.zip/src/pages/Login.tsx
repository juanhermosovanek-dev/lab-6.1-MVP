import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { trackEvent } from '../lib/posthog';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
      setError(error.message);
    } else {
      trackEvent('user_logged_in');
      navigate('/dashboard');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-root px-4">
      <div className="w-full max-w-md bg-panel rounded-xl border border-border-card p-8 shadow-2xl">
        <h1 className="text-2xl font-semibold mb-2 text-text-primary text-center">Bienvenido de nuevo</h1>
        <p className="text-text-secondary text-sm text-center mb-8">Ingresá a tu cuenta de EduPath</p>

        {error && (
          <div className="mb-4 p-3 bg-danger/10 border border-danger/20 text-danger text-sm rounded-lg text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-1">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-root border border-border-card rounded-lg px-4 py-2.5 text-text-primary focus:outline-none focus:border-accent transition-colors"
              placeholder="tu@colegio.edu.ar"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-1">Contraseña</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-root border border-border-card rounded-lg px-4 py-2.5 text-text-primary focus:outline-none focus:border-accent transition-colors"
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-accent hover:bg-accent/90 text-root font-medium py-2.5 rounded-lg transition-colors mt-2 disabled:opacity-50"
          >
            {loading ? 'Ingresando...' : 'Ingresar'}
          </button>
        </form>

        <p className="text-center text-sm text-text-secondary mt-6">
          ¿No tenés cuenta?{' '}
          <Link to="/signup" className="text-accent hover:underline">
            Registrar colegio
          </Link>
        </p>
      </div>
    </div>
  );
}
