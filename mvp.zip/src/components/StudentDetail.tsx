import React, { useState, useEffect } from 'react';
import { Student, Observation } from '../types';
import { supabase } from '../lib/supabase';
import { trackEvent } from '../lib/posthog';
import { MOCK_TEACHERS } from '../lib/constants';
import { Loader2, Trash2, FileText, Send, AlertTriangle } from 'lucide-react';
import { cn } from '../lib/utils';
import ReportModal from './ReportModal';

export default function StudentDetail({ student, onUpdate, onDelete }: { student: Student, onUpdate: () => void, onDelete: () => void }) {
  const [observations, setObservations] = useState<Observation[]>([]);
  const [loadingObs, setLoadingObs] = useState(true);
  
  // Observation form
  const [teacher, setTeacher] = useState(MOCK_TEACHERS[0]);
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [startTime, setStartTime] = useState<number>(Date.now());

  const [isReportOpen, setIsReportOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    fetchObservations();
    setStartTime(Date.now());
  }, [student.id]);

  const fetchObservations = async () => {
    try {
      setLoadingObs(true);
      const { data, error } = await supabase
        .from('observations')
        .select('*')
        .eq('student_id', student.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setObservations(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingObs(false);
    }
  };

  const handleAddObservation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    setIsSubmitting(true);
    try {
      const { error } = await supabase
        .from('observations')
        .insert([{
          student_id: student.id,
          teacher_name: teacher,
          content: content.trim()
        }]);

      if (error) throw error;
      
      const elapsedSeconds = Math.round((Date.now() - startTime) / 1000);
      trackEvent('observation_submitted', { elapsed_seconds: elapsedSeconds });
      
      setContent('');
      setStartTime(Date.now());
      fetchObservations();
    } catch (err) {
      console.error(err);
      alert('Error guardando observación');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteStudent = async () => {
    if (!confirm('¿Seguro que deseás eliminar este alumno y todas sus observaciones?')) return;
    
    setIsDeleting(true);
    try {
      // 1. Delete observations
      await supabase.from('observations').delete().eq('student_id', student.id);
      // 2. Delete student
      await supabase.from('students').delete().eq('id', student.id);
      
      onDelete();
    } catch (err) {
      console.error(err);
      alert('Error al eliminar');
      setIsDeleting(false);
    }
  };

  const gradeDrop = student.grade_t1 - student.grade_t2;
  const hasGradeDrop = gradeDrop > 0.5;
  const hasAttendanceIssue = student.attendance < 85;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Header Actions */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-text-secondary text-sm">{student.year} • {student.subject}</span>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsReportOpen(true)}
            className="flex items-center gap-2 bg-accent text-root font-medium px-4 py-2 rounded-lg hover:bg-accent/90 transition-colors shadow-lg shadow-accent/20"
          >
            <FileText className="w-4 h-4" />
            Generar Reporte
          </button>
          <button 
            onClick={handleDeleteStudent}
            disabled={isDeleting}
            className="flex items-center gap-2 text-text-secondary hover:text-danger px-3 py-2 rounded-lg transition-colors border border-transparent hover:border-danger/20 hover:bg-danger/10"
            title="Eliminar alumno"
          >
            {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Primary Stats Panel */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        
        {/* Status Card */}
        <div className={cn(
          "bg-bg-card border border-border-card rounded-xl p-5 relative overflow-hidden",
          "before:absolute before:top-0 before:left-0 before:right-0 before:h-0.5",
          student.status === 'good' ? "before:bg-success" : 
          student.status === 'warn' ? "before:bg-warn" : "before:bg-danger"
        )}>
          <div className="text-sm text-text-secondary mb-1">Estado General</div>
          <div className={cn(
            "text-2xl font-semibold capitalize",
            student.status === 'good' ? "text-success" : 
            student.status === 'warn' ? "text-warn" : "text-danger"
          )}>
            {student.status === 'good' ? 'Correcto' : student.status === 'warn' ? 'Alerta' : 'Crítico'}
          </div>
        </div>

        {/* Trim 1 Grade */}
        <div className="bg-bg-card border border-border-card rounded-xl p-5 relative overflow-hidden before:absolute before:top-0 before:left-0 before:right-0 before:h-0.5 before:bg-white/10">
          <div className="text-sm text-text-secondary mb-1">Promedio T1</div>
          <div className="text-2xl font-semibold">{student.grade_t1.toFixed(1)}</div>
        </div>

        {/* Trim 2 Grade */}
        <div className="bg-bg-card border border-border-card rounded-xl p-5 relative overflow-hidden before:absolute before:top-0 before:left-0 before:right-0 before:h-0.5 before:bg-white/10 flex flex-col justify-between">
          <div className="text-sm text-text-secondary mb-1">Promedio T2</div>
          <div className="flex items-end gap-2">
            <div className="text-2xl font-semibold">{student.grade_t2.toFixed(1)}</div>
            {hasGradeDrop && (
              <span className="text-xs font-medium text-danger bg-danger/10 px-1.5 py-0.5 rounded flex items-center mb-1">
                ▼ {Math.abs(gradeDrop).toFixed(1)}
              </span>
            )}
            {gradeDrop < 0 && (
              <span className="text-xs font-medium text-success bg-success/10 px-1.5 py-0.5 rounded flex items-center mb-1">
                ▲ {Math.abs(gradeDrop).toFixed(1)}
              </span>
            )}
          </div>
        </div>

        {/* Attendance */}
        <div className="bg-bg-card border border-border-card rounded-xl p-5 relative overflow-hidden before:absolute before:top-0 before:left-0 before:right-0 before:h-0.5 before:bg-white/10">
          <div className="text-sm text-text-secondary mb-1">Asistencia</div>
          <div className="flex items-center justify-between">
            <div className={cn("text-2xl font-semibold", hasAttendanceIssue ? "text-danger" : "text-white")}>
              {student.attendance}%
            </div>
            {hasAttendanceIssue && (
              <AlertTriangle className="w-5 h-5 text-danger" />
            )}
          </div>
        </div>
      </div>

      {/* Observations Section */}
      <div className="bg-bg-card border border-border-card rounded-xl overflow-hidden mt-8">
        <div className="border-b border-border-card p-5 bg-panel/50">
          <h3 className="font-semibold text-lg flex items-center gap-2">
            Registro de Profesores
            <span className="bg-white/10 text-white text-xs py-0.5 px-2 rounded-full font-medium">
              {observations.length}
            </span>
          </h3>
        </div>
        
        <div className="p-5 flex flex-col md:flex-row gap-6">
          
          {/* List */}
          <div className="flex-1 space-y-4 order-2 md:order-1">
            {loadingObs ? (
              <div className="py-8 flex justify-center text-text-secondary">
                <Loader2 className="w-6 h-6 animate-spin" />
              </div>
            ) : observations.length === 0 ? (
              <div className="py-8 text-center text-text-secondary text-sm border border-dashed border-border-card rounded-lg">
                No hay observaciones registradas aún.
              </div>
            ) : (
              observations.map(obs => (
                <div key={obs.id} className="bg-root border-l-4 border-l-accent border-y border-r border-border-card rounded-r-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <span className="font-medium text-sm text-accent">{obs.teacher_name}</span>
                    <span className="text-xs text-text-secondary">
                      {new Date(obs.created_at).toLocaleDateString('es-AR', { day: 'numeric', month: 'short' })}
                    </span>
                  </div>
                  <p className="text-sm text-white/90 italic leading-relaxed whitespace-pre-wrap">
                    "{obs.content}"
                  </p>
                </div>
              ))
            )}
          </div>

          {/* Form */}
          <div className="w-full md:w-80 shrink-0 order-1 md:order-2 bg-root rounded-lg border border-border-card p-4 h-fit sticky top-4">
            <h4 className="text-sm font-medium mb-3">Nueva Observación</h4>
            <form onSubmit={handleAddObservation} className="space-y-3">
              <select 
                value={teacher}
                onChange={e => setTeacher(e.target.value)}
                className="w-full bg-panel border border-border-card rounded-lg px-3 py-2 text-sm text-white focus:border-accent outline-none appearance-none"
              >
                {MOCK_TEACHERS.map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
              
              <textarea 
                required
                value={content}
                onChange={e => setContent(e.target.value)}
                placeholder="Escribí tu observación aquí..."
                rows={4}
                className="w-full bg-panel border border-border-card rounded-lg px-3 py-2 text-sm text-white focus:border-accent outline-none font-sans resize-none"
              />

              <button 
                type="submit" 
                disabled={isSubmitting || !content.trim()}
                className="w-full flex justify-center items-center gap-2 bg-accent/10 hover:bg-accent/20 text-accent font-medium text-sm py-2 rounded-lg transition-colors border border-accent/20 disabled:opacity-50"
              >
                {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                Registrar
              </button>
            </form>
          </div>
        </div>
      </div>

      {isReportOpen && (
        <ReportModal 
          student={student} 
          observations={observations} 
          onClose={() => setIsReportOpen(false)} 
        />
      )}
    </div>
  );
}
