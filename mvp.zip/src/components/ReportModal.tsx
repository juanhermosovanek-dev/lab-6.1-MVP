import React, { useEffect, useState } from 'react';
import { Student, Observation } from '../types';
import { useAuth } from '../context/AuthContext';
import { X, Printer, CheckCircle, AlertTriangle, Download } from 'lucide-react';
import { trackEvent } from '../lib/posthog';

export default function ReportModal({ student, observations, onClose }: { student: Student, observations: Observation[], onClose: () => void }) {
  const { user } = useAuth();
  const schoolName = user?.user_metadata?.school_name || 'Institución Educativa';
  const [isGenerating, setIsGenerating] = useState(true);

  // Simulate the 90 seconds AI generation experience with a quick 1.5s faux-delay
  useEffect(() => {
    trackEvent('report_generated', { student_name: student.name, observation_count: observations.length });
    const timer = setTimeout(() => {
      setIsGenerating(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, [student, observations.length]);

  const gradeDrop = student.grade_t1 - student.grade_t2;
  const hasGradeDrop = gradeDrop > 0.5;
  const hasAttendanceIssue = student.attendance < 85;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-root/90 backdrop-blur-sm p-4">
      {isGenerating ? (
        <div className="text-center space-y-4">
          <div className="w-16 h-16 border-4 border-accent/20 border-t-accent rounded-full animate-spin mx-auto"></div>
          <p className="text-lg font-medium animate-pulse text-white">Consolidando datos académicos...</p>
          <p className="text-sm text-text-secondary">Conectando plataforma de notas y asistencia</p>
        </div>
      ) : (
        <div className="w-full max-w-3xl bg-white text-gray-900 rounded-xl shadow-2xl flex flex-col max-h-[90vh]">
          
          {/* Modal Header Actions (Not part of print) */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50 rounded-t-xl print:hidden shrink-0">
            <h2 className="font-semibold text-gray-700">Vista Previa del Reporte</h2>
            <div className="flex gap-2">
               <button 
                onClick={handlePrint}
                className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded hover:bg-gray-50 transition-colors"
              >
                <Printer className="w-4 h-4" />
                Imprimir PDF
              </button>
              <button 
                onClick={onClose}
                className="p-1.5 text-gray-500 hover:bg-gray-200 rounded transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Actual Report Content (Printable) */}
          <div className="p-8 md:p-12 overflow-y-auto print:p-0 print:overflow-visible">
            
            {/* Header */}
            <div className="border-b-2 border-gray-900 pb-6 mb-8 text-center">
              <h1 className="text-2xl font-bold uppercase tracking-wider mb-1">{schoolName}</h1>
              <h2 className="text-gray-600 font-medium">Reporte de Progreso Académico Integrado</h2>
              <div className="mt-4 inline-flex items-center gap-2 border border-black/10 px-3 py-1 rounded-full text-xs font-semibold bg-gray-50">
                <span>{student.year}</span>
                <span className="w-1 h-1 rounded-full bg-gray-300"></span>
                <span>{student.subject}</span>
              </div>
            </div>

            {/* Student Info & Stats Grid */}
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-8">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{student.name}</h3>
                  <p className="text-sm text-gray-500">ID de Alumno: {student.id.split('-')[0]}</p>
                </div>
                <div>
                  {student.status === 'good' && (
                    <span className="flex items-center gap-1.5 bg-green-100 text-green-800 border border-green-200 px-3 py-1 rounded-full text-sm font-semibold">
                      <CheckCircle className="w-4 h-4" /> En Camino
                    </span>
                  )}
                  {student.status === 'warn' && (
                    <span className="flex items-center gap-1.5 bg-yellow-100 text-yellow-800 border border-yellow-200 px-3 py-1 rounded-full text-sm font-semibold">
                      <AlertTriangle className="w-4 h-4" /> Requiere Atención
                    </span>
                  )}
                  {student.status === 'danger' && (
                    <span className="flex items-center gap-1.5 bg-red-100 text-red-800 border border-red-200 px-3 py-1 rounded-full text-sm font-semibold">
                      <AlertTriangle className="w-4 h-4" /> Riesgo Crítico
                    </span>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4 divide-x divide-gray-200 border-t border-gray-200 pt-6">
                <div className="px-2 text-center">
                  <div className="text-xs text-gray-500 uppercase tracking-wider mb-1">Trimestre 1</div>
                  <div className="text-xl font-semibold text-gray-900">{student.grade_t1.toFixed(1)}</div>
                </div>
                <div className="px-2 text-center">
                  <div className="text-xs text-gray-500 uppercase tracking-wider mb-1">Trimestre 2</div>
                  <div className="text-xl font-bold text-gray-900">{student.grade_t2.toFixed(1)}</div>
                </div>
                <div className="px-2 text-center">
                  <div className="text-xs text-gray-500 uppercase tracking-wider mb-1">Evolución</div>
                  <div className="text-xl font-semibold flex justify-center">
                    {gradeDrop > 0 ? (
                      <span className="text-red-600">-{gradeDrop.toFixed(1)}</span>
                    ) : gradeDrop < 0 ? (
                      <span className="text-green-600">+{Math.abs(gradeDrop).toFixed(1)}</span>
                    ) : (
                      <span className="text-gray-500">=</span>
                    )}
                  </div>
                </div>
                <div className="px-2 text-center">
                  <div className="text-xs text-gray-500 uppercase tracking-wider mb-1">Asistencia</div>
                  <div className="text-xl font-semibold text-gray-900">{student.attendance}%</div>
                </div>
              </div>
            </div>

            {/* Auto-Alerts Section */}
            {(hasAttendanceIssue || hasGradeDrop) && (
              <div className="mb-8 p-5 border border-red-200 bg-red-50 rounded-lg">
                <h4 className="font-bold text-red-900 flex items-center gap-2 mb-3">
                  <AlertTriangle className="w-5 h-5" /> 
                  Alertas Automáticas Detectadas
                </h4>
                <ul className="space-y-2 text-sm text-red-800">
                  {hasAttendanceIssue && (
                    <li className="flex items-start gap-2">
                       <span className="font-bold">•</span>
                       La asistencia del alumno ha caído al {student.attendance}%, por debajo del umbral mínimo requerido del 85%.
                    </li>
                  )}
                  {hasGradeDrop && (
                    <li className="flex items-start gap-2">
                       <span className="font-bold">•</span>
                       Se detectó una caída pronunciada ({gradeDrop.toFixed(1)} pts) en el promedio general del alumno respecto al trimestre anterior.
                    </li>
                  )}
                </ul>
              </div>
            )}

            {/* Observations Table */}
            <div className="mb-8">
              <h4 className="font-bold text-gray-900 mb-4 pb-2 border-b border-gray-200">
                Registro de Observaciones Docentes
              </h4>
              {observations.length === 0 ? (
                <p className="text-sm text-gray-500 italic">No hay observaciones registradas en el período para este alumno.</p>
              ) : (
                <div className="space-y-4">
                  {observations.map(obs => (
                    <div key={obs.id} className="bg-white border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-end mb-2">
                        <span className="font-bold text-sm text-gray-900">{obs.teacher_name}</span>
                        <span className="text-xs text-gray-500">
                          {new Date(obs.created_at).toLocaleDateString('es-AR', { year: 'numeric', month: 'long', day: 'numeric' })}
                        </span>
                      </div>
                      <p className="text-sm text-gray-700 italic leading-relaxed">
                        "{obs.content}"
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer Compliance Note */}
            <div className="mt-16 pt-6 border-t border-gray-300 text-xs text-gray-400 text-center space-y-1">
              <p>Generado automáticamente por EduPath Argentina el {new Date().toLocaleDateString('es-AR')}</p>
              <p>Cláusula de Confidencialidad – En cumplimiento con la Ley Nº 25.326 de Protección de los Datos Personales de la República Argentina.</p>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
