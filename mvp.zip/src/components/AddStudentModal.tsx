import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { calculateStatus } from '../lib/constants';
import { trackEvent } from '../lib/posthog';
import { useAuth } from '../context/AuthContext';
import { X, Loader2 } from 'lucide-react';

export default function AddStudentModal({ onClose, onSuccess }: { onClose: () => void, onSuccess: (s: any) => void }) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    year: 'Year 3',
    subject: 'History',
    attendance: 100,
    grade_t1: 8.5,
    grade_t2: 8.0,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const status = calculateStatus(Number(formData.grade_t2));

    try {
      const payload = {
        user_id: user?.id,
        name: formData.name,
        year: formData.year,
        subject: formData.subject,
        attendance: Number(formData.attendance),
        grade_t1: Number(formData.grade_t1),
        grade_t2: Number(formData.grade_t2),
        status,
      };

      const { data, error } = await supabase
        .from('students')
        .insert([payload])
        .select()
        .single();

      if (error) throw error;
      
      trackEvent('student_added');
      onSuccess(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error guardando alumno');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-root/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-panel border border-border-card rounded-xl shadow-2xl relative">
        <button 
          onClick={onClose}
          className="absolute right-4 top-4 text-text-secondary hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6">
          <h2 className="text-xl font-semibold mb-6">Nuevo Alumno</h2>

          {error && (
            <div className="mb-4 p-3 bg-danger/10 border border-danger/20 text-danger text-sm rounded-lg">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1">Nombre Completo</label>
              <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-root border border-border-card rounded-lg px-3 py-2 text-white focus:border-accent outline-none" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-text-secondary mb-1">Año</label>
                <input required type="text" value={formData.year} onChange={e => setFormData({...formData, year: e.target.value})} className="w-full bg-root border border-border-card rounded-lg px-3 py-2 text-white focus:border-accent outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-text-secondary mb-1">Materia Base</label>
                <input required type="text" value={formData.subject} onChange={e => setFormData({...formData, subject: e.target.value})} className="w-full bg-root border border-border-card rounded-lg px-3 py-2 text-white focus:border-accent outline-none" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1">Asistencia (%)</label>
              <input required type="number" min="0" max="100" value={formData.attendance} onChange={e => setFormData({...formData, attendance: Number(e.target.value)})} className="w-full bg-root border border-border-card rounded-lg px-3 py-2 text-white focus:border-accent outline-none" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-text-secondary mb-1">Nota Trim 1</label>
                <input required type="number" step="0.1" min="1" max="10" value={formData.grade_t1} onChange={e => setFormData({...formData, grade_t1: Number(e.target.value)})} className="w-full bg-root border border-border-card rounded-lg px-3 py-2 text-white focus:border-accent outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-text-secondary mb-1">Nota Trim 2</label>
                <input required type="number" step="0.1" min="1" max="10" value={formData.grade_t2} onChange={e => setFormData({...formData, grade_t2: Number(e.target.value)})} className="w-full bg-root border border-border-card rounded-lg px-3 py-2 text-white focus:border-accent outline-none" />
              </div>
            </div>

            <div className="pt-4 flex justify-end gap-3">
              <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-text-secondary hover:text-white transition-colors">
                Cancelar
              </button>
              <button disabled={loading} type="submit" className="px-5 py-2 bg-accent hover:bg-accent/90 text-root text-sm font-medium rounded-lg transition-colors flex items-center gap-2">
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                Guardar
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
