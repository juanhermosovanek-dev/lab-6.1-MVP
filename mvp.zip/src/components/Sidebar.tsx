import React from 'react';
import { Student } from '../types';
import { Plus, Users } from 'lucide-react';
import { cn } from '../lib/utils';

type SidebarProps = {
  students: Student[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onAddClick: () => void;
  loading: boolean;
};

export default function Sidebar({ students, selectedId, onSelect, onAddClick, loading }: SidebarProps) {
  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="p-4 shrink-0">
        <button 
          onClick={onAddClick}
          className="w-full flex items-center justify-center gap-2 bg-accent/10 hover:bg-accent/20 text-accent py-2 rounded-lg text-sm font-medium transition-colors border border-accent/20"
        >
          <Plus className="w-4 h-4" />
          Nuevo Alumno
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-2 pb-4">
        <div className="px-2 mb-2 flex items-center gap-2 text-xs font-medium text-text-secondary uppercase tracking-wider">
          <Users className="w-3 h-3" />
          Alumnos
        </div>

        {loading ? (
          <div className="px-2 py-4 text-center text-sm text-text-secondary">
            Cargando...
          </div>
        ) : students.length === 0 ? (
          <div className="px-2 py-4 text-center text-xs text-text-secondary">
            No hay alumnos registrados.
          </div>
        ) : (
          <div className="space-y-0.5">
            {students.map((student) => (
              <button
                key={student.id}
                onClick={() => onSelect(student.id)}
                className={cn(
                  "w-full text-left px-3 py-2 rounded-lg text-sm transition-colors duration-150 flex items-center gap-3 group relative overflow-hidden",
                  selectedId === student.id 
                    ? "bg-accent/10 text-white font-medium" 
                    : "text-text-secondary hover:bg-white/5 hover:text-white"
                )}
              >
                <div className={cn(
                  "w-1.5 h-1.5 rounded-full shrink-0",
                  student.status === 'good' ? 'bg-success' : '',
                  student.status === 'warn' ? 'bg-warn' : '',
                  student.status === 'danger' ? 'bg-danger' : '',
                )} />
                <span className="truncate">{student.name}</span>
                {selectedId === student.id && (
                  <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-accent rounded-r-full" />
                )}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
